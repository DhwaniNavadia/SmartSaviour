abstract class FontFamilyManager {
  FontFamilyManager._();
  static const String poppins = "Poppins";
}
