package com.example.dr_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
